LapSimPro Windows coach overlay
Replace this placeholder with the real LapSimPro-Setup build for paying subscribers.
